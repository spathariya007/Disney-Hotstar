# Disney+ Hotstar Frontend Clone 
Hi, This is a Disney+ Hotstar front-end clone that I have built using pure HTML, CSS, and JavaScript.

##### I don't own any rights from Disney and Hotstar as a company, This website was made for educational purposes to be shown as a piece of the portfolio. There are not any commercial or monetary purposes

## Installation
* Clone the repository
* Then click on the *index.html* folder
* Done :)

## Libraries/Technologies used
* Html
* CSS
* JavaScript

## Screenshots
![Website Screenshot](https://github.com/kishlayjeet/Disney-Plus-Hotsatar-Clone/blob/main/preview.png?raw=true)
